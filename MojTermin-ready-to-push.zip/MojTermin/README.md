# MojTermin

Appointment booking application (**Moj Termin**).

Built with Vite + React + TanStack Router + PGlite.

## Getting Started

```bash
npm install
npm run dev
```

The app will be available at `http://localhost:8080`.

## Scripts

- `npm run dev` – start development server
- `npm run build` – production build
- `npm run typecheck` – TypeScript check
- `npm test` – run tests

## Notes

This repository was prepared from a Grok workspace export.
