import { addDays, format } from "date-fns";

export const CATEGORIES = [
  { id: "zdravje", label: "Zdravje" },
  { id: "delo", label: "Delo" },
  { id: "osebno", label: "Osebno" },
  { id: "drugo", label: "Drugo" },
] as const;

export type Category = (typeof CATEGORIES)[number]["id"];

export type Appointment = {
  id: string;
  title: string;
  date: string;
  time: string;
  durationMin: number;
  place: string;
  notes: string;
  category: Category;
  done: boolean;
};

const KEY = "moj-terminecek.v1";

const CATEGORY_IDS = new Set<string>(CATEGORIES.map((item) => item.id));

export function isoDate(date: Date): string {
  return format(date, "yyyy-MM-dd");
}

export function parseIsoDate(iso: string): Date {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(year ?? 1970, (month ?? 1) - 1, day ?? 1);
}

export function atDateTime(date: string, time: string): Date {
  const [hours, minutes] = time.split(":").map(Number);
  const value = parseIsoDate(date);
  value.setHours(hours ?? 0, minutes ?? 0, 0, 0);
  return value;
}

export function slCount(
  n: number,
  one: string,
  two: string,
  few: string,
  many: string,
): string {
  const mod = Math.abs(Math.trunc(n)) % 100;
  const word = mod === 1 ? one : mod === 2 ? two : mod === 3 || mod === 4 ? few : many;
  return `${n} ${word}`;
}

export function durationPhrase(mins: number): string {
  if (mins < 60) return slCount(mins, "minuta", "minuti", "minute", "minut");
  const hours = Math.floor(mins / 60);
  const rest = mins % 60;
  const hourLabel = slCount(hours, "ura", "uri", "ure", "ur");
  if (rest === 0) return hourLabel;
  return `${hourLabel} ${slCount(rest, "minuta", "minuti", "minute", "minut")}`;
}

export function relativePhrase(from: Date, to: Date): string {
  const mins = Math.round((to.getTime() - from.getTime()) / 60000);
  if (mins <= 0) return "zdaj";
  if (mins < 60) return `čez ${slCount(mins, "minuto", "minuti", "minute", "minut")}`;
  const hours = Math.floor(mins / 60);
  const rest = mins % 60;
  if (hours < 24) {
    const hourLabel = `čez ${slCount(hours, "uro", "uri", "ure", "ur")}`;
    if (rest === 0) return hourLabel;
    return `${hourLabel} ${slCount(rest, "minuto", "minuti", "minute", "minut")}`;
  }
  const days = Math.max(1, Math.round(mins / (60 * 24)));
  if (days === 1) return "jutri";
  return `čez ${slCount(days, "dan", "dneva", "dni", "dni")}`;
}

export function categoryLabel(id: Category): string {
  return CATEGORIES.find((item) => item.id === id)?.label ?? "Drugo";
}

function isAppointment(value: unknown): value is Appointment {
  if (!value || typeof value !== "object") return false;
  const item = value as Record<string, unknown>;
  return (
    typeof item.id === "string" &&
    typeof item.title === "string" &&
    typeof item.date === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(item.date) &&
    typeof item.time === "string" &&
    /^\d{2}:\d{2}$/.test(item.time) &&
    typeof item.durationMin === "number" &&
    Number.isFinite(item.durationMin) &&
    typeof item.place === "string" &&
    typeof item.notes === "string" &&
    typeof item.category === "string" &&
    CATEGORY_IDS.has(item.category) &&
    typeof item.done === "boolean"
  );
}

export function seedAppointments(today: Date): Appointment[] {
  const on = (offset: number) => isoDate(addDays(today, offset));
  return [
    {
      id: "seed-1",
      title: "Tek ob reki",
      date: on(-1),
      time: "07:00",
      durationMin: 40,
      place: "Pot ob Ljubljanici",
      notes: "Lahkoten tempo.",
      category: "osebno",
      done: true,
    },
    {
      id: "seed-2",
      title: "Sprehod z Majo",
      date: on(0),
      time: "11:00",
      durationMin: 60,
      place: "Park Tivoli",
      notes: "",
      category: "osebno",
      done: false,
    },
    {
      id: "seed-3",
      title: "Kava z Ano",
      date: on(0),
      time: "17:00",
      durationMin: 90,
      place: "Kavarna Čokl",
      notes: "Prinesi knjigo, ki si jo obljubil.",
      category: "osebno",
      done: false,
    },
    {
      id: "seed-4",
      title: "Tedenski sestanek",
      date: on(1),
      time: "08:15",
      durationMin: 30,
      place: "Pisarna, 3. nadstropje",
      notes: "Pripravi kratek pregled tedna.",
      category: "delo",
      done: false,
    },
    {
      id: "seed-5",
      title: "Frizer",
      date: on(1),
      time: "12:30",
      durationMin: 45,
      place: "Salon Mimo",
      notes: "",
      category: "drugo",
      done: false,
    },
    {
      id: "seed-6",
      title: "Zobozdravnik",
      date: on(2),
      time: "09:30",
      durationMin: 45,
      place: "Ordinacija Novak",
      notes: "Kontrola po plombi.",
      category: "zdravje",
      done: false,
    },
    {
      id: "seed-7",
      title: "Joga",
      date: on(3),
      time: "18:30",
      durationMin: 60,
      place: "Studio Gibanje",
      notes: "Prinesi brisačo.",
      category: "osebno",
      done: false,
    },
    {
      id: "seed-8",
      title: "Pregled krvi",
      date: on(4),
      time: "07:40",
      durationMin: 20,
      place: "Zdravstveni dom Center",
      notes: "Na tešče.",
      category: "zdravje",
      done: false,
    },
    {
      id: "seed-9",
      title: "Klic z računovodjo",
      date: on(5),
      time: "16:00",
      durationMin: 30,
      place: "Zoom",
      notes: "Pri roki imej račune.",
      category: "delo",
      done: false,
    },
    {
      id: "seed-10",
      title: "Večerja pri starših",
      date: on(6),
      time: "19:00",
      durationMin: 120,
      place: "Doma",
      notes: "Prinesi sladico.",
      category: "drugo",
      done: false,
    },
    {
      id: "seed-11",
      title: "Servis kolesa",
      date: on(12),
      time: "15:00",
      durationMin: 40,
      place: "Kolesarna Rog",
      notes: "",
      category: "drugo",
      done: false,
    },
  ];
}

export function loadAppointments(today: Date): Appointment[] {
  if (typeof window === "undefined") return seedAppointments(today);
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) {
      const seeded = seedAppointments(today);
      window.localStorage.setItem(KEY, JSON.stringify({ items: seeded }));
      return seeded;
    }
    const parsed = JSON.parse(raw) as { items?: unknown };
    if (!parsed || !Array.isArray(parsed.items)) return [];
    return parsed.items.filter(isAppointment);
  } catch {
    return seedAppointments(today);
  }
}

export function saveAppointments(items: Appointment[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify({ items }));
}

export function hasSamples(items: Appointment[]): boolean {
  return items.some((item) => item.id.startsWith("seed-"));
}

export function durationShort(mins: number): string {
  if (mins >= 60 && mins % 60 === 0) return slCount(mins / 60, "ura", "uri", "ure", "ur");
  if (mins > 60) return `${Math.floor(mins / 60)} h ${mins % 60}`;
  return `${mins} min`;
}
