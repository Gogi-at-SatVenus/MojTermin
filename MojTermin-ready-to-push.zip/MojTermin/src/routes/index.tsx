import { createFileRoute } from "@tanstack/react-router";
import { AppointmentBook } from "@/components/appointment-book";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AppointmentBook />;
}
