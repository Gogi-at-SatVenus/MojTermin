import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import {
  addMinutes,
  format,
  isSameDay,
  isSameMonth,
} from "date-fns";
import { sl } from "date-fns/locale";
import {
  Bookmark,
  Briefcase,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Heart,
  MapPin,
  Plus,
  Search,
  Stethoscope,
  X,
} from "lucide-react";
import { clsx } from "clsx";
import {
  type Appointment,
  type Category,
  CATEGORIES,
  atDateTime,
  categoryLabel,
  durationPhrase,
  durationShort,
  hasSamples,
  isoDate,
  loadAppointments,
  parseIsoDate,
  relativePhrase,
  saveAppointments,
  seedAppointments,
  slCount,
} from "@/lib/appointments";

const WEEKDAYS = ["Po", "To", "Sr", "Če", "Pe", "So", "Ne"] as const;
const DURATIONS = [15, 30, 45, 60, 90, 120] as const;

const CATEGORY_ICON = {
  zdravje: Stethoscope,
  delo: Briefcase,
  osebno: Heart,
  drugo: Bookmark,
} as const;

type Draft = {
  id: string | null;
  title: string;
  date: string;
  time: string;
  durationMin: number;
  place: string;
  notes: string;
  category: Category;
  done: boolean;
};

function cap(value: string): string {
  if (!value) return value;
  return value.charAt(0).toLocaleUpperCase("sl") + value.slice(1);
}

function dayStamp(date: Date): string {
  return cap(format(date, "EEEE, d. MMMM", { locale: sl }));
}

function dateOnlyLabel(dateIso: string, today: Date): string {
  const date = parseIsoDate(dateIso);
  if (isSameDay(date, today)) return "Danes";
  const tomorrow = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
  if (isSameDay(date, tomorrow)) return "Jutri";
  const yesterday = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1);
  if (isSameDay(date, yesterday)) return "Včeraj";
  return cap(format(date, "d. MMM", { locale: sl }));
}

function openCount(items: Appointment[], now: Date): number {
  return items.filter((item) => !item.done && appointmentEnd(item).getTime() >= now.getTime()).length;
}

function monthStamp(date: Date): string {
  return cap(format(date, "LLLL yyyy", { locale: sl }));
}

function whenLabel(dateIso: string, time: string, today: Date): string {
  const date = parseIsoDate(dateIso);
  const clock = time;
  if (isSameDay(date, today)) return `Danes ob ${clock}`;
  const tomorrow = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
  if (isSameDay(date, tomorrow)) return `Jutri ob ${clock}`;
  const yesterday = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1);
  if (isSameDay(date, yesterday)) return `Včeraj ob ${clock}`;
  return `${cap(format(date, "EEEE, d. MMM", { locale: sl }))} ob ${clock}`;
}

function shiftMonth(cursor: Date, delta: number, selected: string) {
  const next = new Date(cursor.getFullYear(), cursor.getMonth() + delta, 1);
  const current = parseIsoDate(selected);
  const last = new Date(next.getFullYear(), next.getMonth() + 1, 0).getDate();
  const day = Math.min(current.getDate(), last);
  return {
    cursor: next,
    selected: isoDate(new Date(next.getFullYear(), next.getMonth(), day)),
  };
}

function monthCells(cursor: Date): Array<Date | null> {
  const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
  const lead = (first.getDay() + 6) % 7;
  const count = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const cells: Array<Date | null> = Array.from({ length: lead }, () => null);
  for (let day = 1; day <= count; day += 1) {
    cells.push(new Date(cursor.getFullYear(), cursor.getMonth(), day));
  }
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

function suggestedTime(dateIso: string, today: Date): string {
  if (dateIso !== isoDate(today)) return "09:00";
  const total = today.getHours() * 60 + today.getMinutes();
  const rounded = Math.min(23 * 60 + 30, Math.ceil((total + 15) / 30) * 30);
  const hours = String(Math.floor(rounded / 60)).padStart(2, "0");
  const minutes = String(rounded % 60).padStart(2, "0");
  return `${hours}:${minutes}`;
}

function blankDraft(dateIso: string, today: Date): Draft {
  return {
    id: null,
    title: "",
    date: dateIso,
    time: suggestedTime(dateIso, today),
    durationMin: 60,
    place: "",
    notes: "",
    category: "osebno",
    done: false,
  };
}

function appointmentEnd(item: Appointment): Date {
  return addMinutes(atDateTime(item.date, item.time), item.durationMin);
}

function nextAppointment(items: Appointment[], now: Date): Appointment | null {
  const upcoming = items
    .filter((item) => !item.done && appointmentEnd(item).getTime() >= now.getTime())
    .sort((a, b) => atDateTime(a.date, a.time).getTime() - atDateTime(b.date, b.time).getTime());
  return upcoming[0] ?? null;
}

function statusOf(item: Appointment, now: Date): "done" | "now" | "missed" | "upcoming" {
  if (item.done) return "done";
  const start = atDateTime(item.date, item.time).getTime();
  const end = appointmentEnd(item).getTime();
  const stamp = now.getTime();
  if (stamp >= start && stamp <= end) return "now";
  if (stamp > end) return "missed";
  return "upcoming";
}

function dotsFor(items: Appointment[], dateIso: string): Category[] {
  const seen = new Set<Category>();
  for (const item of items) {
    if (item.date === dateIso) seen.add(item.category);
  }
  return CATEGORIES.map((item) => item.id).filter((id) => seen.has(id)).slice(0, 3);
}

const DOT: Record<Category, string> = {
  zdravje: "bg-ribbon",
  delo: "bg-ink",
  osebno: "bg-sage",
  drugo: "bg-muted",
};

const CHIP: Record<Category, string> = {
  zdravje: "bg-ribbon-soft text-ribbon",
  delo: "bg-paper text-ink",
  osebno: "bg-sage-soft text-sage",
  drugo: "bg-paper text-muted",
};

export function AppointmentBook() {
  const [now, setNow] = useState(() => new Date());
  const [items, setItems] = useState<Appointment[]>(() => seedAppointments(new Date()));
  const [cursor, setCursor] = useState(() => {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), 1);
  });
  const [selected, setSelected] = useState(() => isoDate(new Date()));
  const [live, setLive] = useState(false);
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Draft | null>(null);
  const agendaRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const today = new Date();
    setNow(today);
    setItems(loadAppointments(today));
    setLive(true);
    const id = window.setInterval(() => setNow(new Date()), 30000);
    return () => window.clearInterval(id);
  }, []);

  function commit(next: Appointment[]) {
    setItems(next);
    saveAppointments(next);
  }

  function openNew(dateIso: string) {
    setEditing(blankDraft(dateIso, now));
  }

  function openEdit(item: Appointment) {
    setEditing({ ...item, id: item.id });
  }

  function reveal(dateIso: string) {
    const date = parseIsoDate(dateIso);
    setSelected(dateIso);
    setCursor(new Date(date.getFullYear(), date.getMonth(), 1));
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    agendaRef.current?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
  }

  const todayIso = isoDate(now);
  const needle = query.trim().toLocaleLowerCase("sl");
  const selectedItems = items
    .filter((item) => item.date === selected)
    .sort((a, b) => a.time.localeCompare(b.time));
  const results = needle
    ? items
        .filter((item) => {
          const hay = `${item.title} ${item.place} ${item.notes} ${categoryLabel(item.category)}`.toLocaleLowerCase(
            "sl",
          );
          return hay.includes(needle);
        })
        .sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))
    : [];
  const upcoming = nextAppointment(items, now);
  const samples = hasSamples(items);
  const cells = monthCells(cursor);
  const selectedDate = parseIsoDate(selected);
  const inMonth = isSameMonth(selectedDate, cursor);

  return (
    <div className="min-h-screen">
      <main
        className="mx-auto max-w-5xl px-4 py-6 md:px-8 md:py-10"
        inert={editing ? true : undefined}
      >
        <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-ribbon">Osebni zvezek</p>
            <h1 className="mt-1 font-display text-4xl leading-none text-ink sm:text-5xl">Moj terminček</h1>
            <p className="mt-3 text-sm text-muted">
              {slCount(openCount(items, now), "odprt termin", "odprta termina", "odprti termini", "odprtih terminov")}
            </p>
          </div>
          <button
            type="button"
            onClick={() => openNew(selected)}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-ink px-5 text-sm font-medium text-foam transition-opacity duration-200 hover:opacity-90"
          >
            <Plus className="size-4" aria-hidden />
            Nov termin
          </button>
        </header>

        {samples ? (
          <div className="mt-5 flex flex-col gap-3 rounded-card border border-line bg-sage-soft/70 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-ink">Vzorčni termini, da vidiš, kako zvezek deluje.</p>
            <div className="flex gap-2">
              <button
                type="button"
                className="h-11 rounded-full px-4 text-sm font-medium text-ink"
                onClick={() =>
                  commit(
                    items.map((item) =>
                      item.id.startsWith("seed-") ? { ...item, id: crypto.randomUUID() } : item,
                    ),
                  )
                }
              >
                Obdrži
              </button>
              <button
                type="button"
                className="h-11 rounded-full bg-sheet px-4 text-sm font-medium text-ribbon"
                onClick={() => commit(items.filter((item) => !item.id.startsWith("seed-")))}
              >
                Počisti
              </button>
            </div>
          </div>
        ) : null}

        <section className="panel relative mt-5 overflow-hidden p-5 md:p-6">
          <div className="absolute inset-y-0 left-0 w-1.5 bg-ribbon" aria-hidden />
          {upcoming ? (
            <button type="button" onClick={() => reveal(upcoming.date)} className="block w-full pl-3 text-left">
              <p className="text-xs font-medium uppercase tracking-widest text-ribbon">
                {statusOf(upcoming, now) === "now" ? "Zdaj" : "Naslednji"}
              </p>
              <h2 className="mt-1 font-display text-3xl text-ink">{upcoming.title}</h2>
              <p className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-muted">
                <span>{whenLabel(upcoming.date, upcoming.time, now)}</span>
                {upcoming.place ? (
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="size-3.5" aria-hidden />
                    {upcoming.place}
                  </span>
                ) : null}
              </p>
              {live ? (
                <p className="mt-3 font-display text-xl text-ink">
                  {statusOf(upcoming, now) === "now"
                    ? `do ${format(appointmentEnd(upcoming), "HH:mm")}`
                    : relativePhrase(now, atDateTime(upcoming.date, upcoming.time))}
                </p>
              ) : null}
            </button>
          ) : (
            <div className="pl-3">
              <p className="text-xs font-medium uppercase tracking-widest text-sage">Prosto</p>
              <h2 className="mt-1 font-display text-3xl text-ink">Nič te ne čaka.</h2>
              <p className="mt-2 text-sm text-muted">Ko se dogovoriš, dodaj termin sem.</p>
            </div>
          )}
        </section>

        <div className="mt-5 grid items-start gap-5 lg:grid-cols-3">
          <section className="bookmark panel px-4 pb-4 pt-7 lg:col-span-1">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-2xl text-ink">{monthStamp(cursor)}</h2>
              <div className="flex shrink-0 items-center">
                <IconButton
                  label="Prejšnji mesec"
                  onClick={() => {
                    const moved = shiftMonth(cursor, -1, selected);
                    setCursor(moved.cursor);
                    setSelected(moved.selected);
                  }}
                >
                  <ChevronLeft className="size-5" />
                </IconButton>
                <IconButton
                  label="Naslednji mesec"
                  onClick={() => {
                    const moved = shiftMonth(cursor, 1, selected);
                    setCursor(moved.cursor);
                    setSelected(moved.selected);
                  }}
                >
                  <ChevronRight className="size-5" />
                </IconButton>
              </div>
            </div>
            <button
              type="button"
              className="mt-1 h-10 text-sm font-medium text-ribbon"
              onClick={() => {
                setCursor(new Date(now.getFullYear(), now.getMonth(), 1));
                setSelected(todayIso);
              }}
            >
              Skoči na danes
            </button>

            <div className="mt-2 grid grid-cols-7 gap-1">
              {WEEKDAYS.map((day) => (
                <div key={day} className="pb-1 text-center text-xs font-medium text-muted">
                  {day}
                </div>
              ))}
              {cells.map((date, index) => {
                if (!date) return <div key={`empty-${index}`} />;
                const iso = isoDate(date);
                const isSelected = iso === selected;
                const isToday = iso === todayIso;
                const dots = dotsFor(items, iso);
                return (
                  <button
                    key={iso}
                    type="button"
                    aria-pressed={isSelected}
                    aria-label={dayStamp(date)}
                    onClick={() => setSelected(iso)}
                    className="flex h-14 flex-col items-center justify-center gap-1 rounded-2xl transition-colors duration-200 hover:bg-paper"
                  >
                    <span
                      className={clsx(
                        "flex size-9 items-center justify-center rounded-full text-sm tabular-nums",
                        isSelected && "bg-ink text-foam",
                        !isSelected && isToday && "text-ribbon ring-2 ring-ribbon",
                        !isSelected && !isToday && "text-ink",
                      )}
                    >
                      {date.getDate()}
                    </span>
                    <span className="flex h-1.5 gap-0.5" aria-hidden>
                      {dots.map((cat) => (
                        <span key={cat} className={clsx("size-1.5 rounded-full", DOT[cat])} />
                      ))}
                    </span>
                  </button>
                );
              })}
            </div>

            <label className="relative mt-3 block">
              <span className="sr-only">Iskanje</span>
              <Search
                className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted"
                aria-hidden
              />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Išči naslov ali kraj"
                className="h-12 w-full rounded-full border border-line bg-paper pr-11 pl-10 text-sm outline-none placeholder:text-muted"
              />
              {query ? (
                <button
                  type="button"
                  aria-label="Počisti iskanje"
                  onClick={() => setQuery("")}
                  className="absolute top-1/2 right-1 flex size-10 -translate-y-1/2 items-center justify-center rounded-full text-muted"
                >
                  <X className="size-4" />
                </button>
              ) : null}
            </label>
          </section>

          <section ref={agendaRef} className="scroll-mt-6 lg:col-span-2">
            {needle ? (
              <div>
                <h2 className="font-display text-3xl text-ink">Iskanje</h2>
                <p className="mt-1 text-sm text-muted">
                  {slCount(results.length, "zadetek", "zadetka", "zadetki", "zadetkov")}
                </p>
                <div className="mt-4 flex flex-col gap-3">
                  {results.length === 0 ? (
                    <EmptyNote
                      title="Nič ne ustreza."
                      body="Poskusi z drugim naslovom, krajem ali kategorijo."
                    />
                  ) : (
                    results.map((item) => (
                      <AppointmentRow
                        key={item.id}
                        item={item}
                        now={now}
                        showDate
                        onOpen={() => openEdit(item)}
                        onToggle={() =>
                          commit(items.map((row) => (row.id === item.id ? { ...row, done: !row.done } : row)))
                        }
                      />
                    ))
                  )}
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-end justify-between gap-3">
                  <h2 className="flex items-end gap-3">
                    <span className="font-display text-6xl leading-none tabular-nums text-ink">
                      {selectedDate.getDate()}
                    </span>
                    <span className="pb-1">
                      <span className="flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-muted">
                        {cap(format(selectedDate, "EEEE", { locale: sl }))}
                        {selected === todayIso ? (
                          <span className="rounded-full bg-ribbon-soft px-2 py-0.5 text-xs font-medium tracking-normal text-ribbon normal-case">
                            danes
                          </span>
                        ) : null}
                      </span>
                      <span className="mt-1 block font-display text-2xl text-ink">
                        {cap(format(selectedDate, "LLLL", { locale: sl }))}
                      </span>
                    </span>
                  </h2>
                  {!inMonth ? (
                    <button
                      type="button"
                      className="h-11 text-sm font-medium text-ribbon"
                      onClick={() => setCursor(new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1))}
                    >
                      Pokaži v koledarju
                    </button>
                  ) : null}
                </div>
                <p className="mt-2 text-sm text-muted">
                  {selectedItems.length === 0
                    ? "Brez terminov"
                    : slCount(selectedItems.length, "termin", "termina", "termini", "terminov")}
                </p>
                <div className="mt-4 flex flex-col gap-3">
                  {selectedItems.length === 0 ? (
                    <EmptyNote
                      title="Ta dan je prost."
                      body="Dodaj termin, da ga ne pozabiš."
                      action="Dodaj termin"
                      onAction={() => openNew(selected)}
                    />
                  ) : (
                    selectedItems.map((item) => (
                      <AppointmentRow
                        key={item.id}
                        item={item}
                        now={now}
                        onOpen={() => openEdit(item)}
                        onToggle={() =>
                          commit(items.map((row) => (row.id === item.id ? { ...row, done: !row.done } : row)))
                        }
                      />
                    ))
                  )}
                </div>
              </div>
            )}
          </section>
        </div>
      </main>
      {editing ? (
        <Editor
          initial={editing}
          onClose={() => setEditing(null)}
          onDelete={(id) => {
            commit(items.filter((item) => item.id !== id));
            setEditing(null);
          }}
          onSave={(draft) => {
            const nextItem: Appointment = {
              id: draft.id ?? crypto.randomUUID(),
              title: draft.title.trim(),
              date: draft.date,
              time: draft.time,
              durationMin: draft.durationMin,
              place: draft.place.trim(),
              notes: draft.notes.trim(),
              category: draft.category,
              done: draft.done,
            };
            const exists = items.some((item) => item.id === nextItem.id);
            commit(exists ? items.map((item) => (item.id === nextItem.id ? nextItem : item)) : [...items, nextItem]);
            setSelected(nextItem.date);
            const date = parseIsoDate(nextItem.date);
            setCursor(new Date(date.getFullYear(), date.getMonth(), 1));
            setEditing(null);
          }}
        />
      ) : null}
    </div>
  );
}

function IconButton({
  label,
  onClick,
  children,
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="flex size-11 items-center justify-center rounded-full text-ink transition-colors duration-200 hover:bg-paper"
    >
      {children}
    </button>
  );
}

function EmptyNote({
  title,
  body,
  action,
  onAction,
}: {
  title: string;
  body: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="panel flex flex-col items-center px-6 py-10 text-center">
      <span className="flex size-12 items-center justify-center rounded-full bg-ribbon-soft text-ribbon">
        <CalendarDays className="size-5" aria-hidden />
      </span>
      <p className="mt-4 font-display text-2xl text-ink">{title}</p>
      <p className="mt-1 max-w-sm text-sm text-pretty text-muted">{body}</p>
      {action && onAction ? (
        <button
          type="button"
          onClick={onAction}
          className="mt-5 inline-flex h-11 items-center rounded-full bg-ink px-5 text-sm font-medium text-foam"
        >
          {action}
        </button>
      ) : null}
    </div>
  );
}

function AppointmentRow({
  item,
  now,
  showDate,
  onOpen,
  onToggle,
}: {
  item: Appointment;
  now: Date;
  showDate?: boolean;
  onOpen: () => void;
  onToggle: () => void;
}) {
  const status = statusOf(item, now);
  const Icon = CATEGORY_ICON[item.category];
  const quiet = status === "done" || status === "missed";
  return (
    <article className="panel flex items-stretch gap-2 p-3 sm:gap-3 sm:p-4">
      <div className="flex w-16 shrink-0 flex-col justify-center text-right">
        <p className={clsx("font-display text-xl leading-none tabular-nums", quiet ? "text-muted" : "text-ink")}>
          {item.time}
        </p>
        <p className="mt-1 text-xs text-muted">{durationShort(item.durationMin)}</p>
      </div>
      <button type="button" onClick={onOpen} className="min-w-0 flex-1 rounded-xl px-1 py-1 text-left">
        <p className={clsx("truncate font-medium", quiet && "text-muted line-through")}>{item.title}</p>
        {(showDate || item.place) && (
          <p className="mt-1 flex min-w-0 items-center gap-1 text-sm text-muted">
            {showDate ? <span className="shrink-0">{dateOnlyLabel(item.date, now)}</span> : null}
            {showDate && item.place ? <span aria-hidden>·</span> : null}
            {item.place ? (
              <span className="inline-flex min-w-0 items-center gap-1">
                <MapPin className="size-3.5 shrink-0" aria-hidden />
                <span className="truncate">{item.place}</span>
              </span>
            ) : null}
          </p>
        )}
        <span className="mt-2 inline-flex items-center gap-2">
          <span className={clsx("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium", CHIP[item.category])}>
            <Icon className="size-3.5" aria-hidden />
            {categoryLabel(item.category)}
          </span>
          {status === "now" ? <span className="text-xs font-medium text-sage">Zdaj</span> : null}
          {status === "missed" ? <span className="text-xs font-medium text-ribbon">Zamujen</span> : null}
        </span>
        {item.notes ? <p className="mt-2 truncate text-sm text-pretty text-muted">{item.notes}</p> : null}
      </button>
      <button
        type="button"
        aria-pressed={item.done}
        aria-label={item.done ? "Označi kot odprto" : "Označi kot opravljeno"}
        onClick={onToggle}
        className={clsx(
          "mt-1 flex size-11 shrink-0 items-center justify-center self-start rounded-full border transition-colors duration-200",
          item.done ? "border-sage bg-sage text-foam" : "border-line bg-sheet text-transparent hover:text-muted",
        )}
      >
        <Check className="size-4" />
      </button>
    </article>
  );
}

function Editor({
  initial,
  onClose,
  onSave,
  onDelete,
}: {
  initial: Draft;
  onClose: () => void;
  onSave: (draft: Draft) => void;
  onDelete: (id: string) => void;
}) {
  const [draft, setDraft] = useState(initial);
  const [error, setError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const titleRef = useRef<HTMLInputElement>(null);
  const headingId = useId();

  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    titleRef.current?.focus();
  }, []);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") closeRef.current();
    }
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  function patch(partial: Partial<Draft>) {
    setDraft((current) => ({ ...current, ...partial }));
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-ink/40" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={headingId}
        className="panel relative z-10 max-h-[92vh] w-full overflow-y-auto p-5 sm:max-w-lg sm:p-7"
      >
        <div className="flex items-start justify-between gap-3">
          <h2 id={headingId} className="font-display text-3xl text-ink">
            {draft.id ? "Uredi termin" : "Nov termin"}
          </h2>
          <button
            type="button"
            aria-label="Zapri"
            onClick={onClose}
            className="flex size-11 items-center justify-center rounded-full text-ink hover:bg-paper"
          >
            <X className="size-5" />
          </button>
        </div>
        <form
          className="mt-4 flex flex-col gap-4"
          onSubmit={(event) => {
            event.preventDefault();
            if (!draft.title.trim()) {
              setError("Vpiši naslov.");
              titleRef.current?.focus();
              return;
            }
            if (!draft.date || !draft.time) {
              setError("Izberi datum in uro.");
              return;
            }
            onSave(draft);
          }}
        >
          <div>
            <label htmlFor="termin-naslov" className="text-xs font-medium uppercase tracking-widest text-muted">
              Naslov
            </label>
            <input
              ref={titleRef}
              id="termin-naslov"
              value={draft.title}
              maxLength={80}
              onChange={(event) => {
                setError("");
                patch({ title: event.target.value });
              }}
              placeholder="Na primer zobozdravnik"
              className="mt-1 h-12 w-full border-b border-line bg-transparent font-display text-2xl outline-none placeholder:text-muted"
            />
            {error ? (
              <p role="alert" className="mt-2 text-sm text-ribbon">
                {error}
              </p>
            ) : null}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Datum">
              <input
                type="date"
                required
                value={draft.date}
                onChange={(event) => patch({ date: event.target.value })}
                className="h-12 w-full rounded-xl border border-line bg-paper px-3 text-sm"
              />
            </Field>
            <Field label="Ura">
              <input
                type="time"
                required
                step={300}
                value={draft.time}
                onChange={(event) => patch({ time: event.target.value })}
                className="h-12 w-full rounded-xl border border-line bg-paper px-3 text-sm"
              />
            </Field>
          </div>

          <fieldset>
            <legend className="text-xs font-medium uppercase tracking-widest text-muted">Trajanje</legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {DURATIONS.map((mins) => (
                <button
                  key={mins}
                  type="button"
                  aria-pressed={draft.durationMin === mins}
                  onClick={() => patch({ durationMin: mins })}
                  className={clsx(
                    "h-11 rounded-full px-3 text-sm",
                    draft.durationMin === mins ? "bg-ink text-foam" : "border border-line bg-paper text-ink",
                  )}
                >
                  {durationPhrase(mins)}
                </button>
              ))}
            </div>
          </fieldset>

          <fieldset>
            <legend className="text-xs font-medium uppercase tracking-widest text-muted">Kategorija</legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {CATEGORIES.map((category) => {
                const Icon = CATEGORY_ICON[category.id];
                const active = draft.category === category.id;
                return (
                  <button
                    key={category.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => patch({ category: category.id })}
                    className={clsx(
                      "inline-flex h-11 items-center justify-center gap-2 rounded-full text-sm",
                      active ? "bg-ink text-foam" : "border border-line bg-paper text-ink",
                    )}
                  >
                    <Icon className="size-4" aria-hidden />
                    {category.label}
                  </button>
                );
              })}
            </div>
          </fieldset>

          <Field label="Kraj">
            <input
              value={draft.place}
              maxLength={80}
              onChange={(event) => patch({ place: event.target.value })}
              placeholder="Ordinacija, pisarna, dom…"
              className="h-12 w-full rounded-xl border border-line bg-paper px-3 text-sm outline-none placeholder:text-muted"
            />
          </Field>

          <Field label="Opomba">
            <textarea
              value={draft.notes}
              maxLength={400}
              rows={3}
              onChange={(event) => patch({ notes: event.target.value })}
              placeholder="Kaj si želiš zapomniti?"
              className="w-full resize-none rounded-xl border border-line bg-paper px-3 py-3 text-sm outline-none placeholder:text-muted"
            />
          </Field>

          <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
            {draft.id ? (
              confirmDelete ? (
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted">Res izbrišem?</span>
                  <button
                    type="button"
                    onClick={() => onDelete(draft.id!)}
                    className="h-11 rounded-full px-3 font-medium text-ribbon"
                  >
                    Da, izbriši
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(false)}
                    className="h-11 rounded-full px-3 font-medium text-ink"
                  >
                    Ne
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDelete(true)}
                  className="h-11 self-start rounded-full px-3 text-sm font-medium text-ribbon"
                >
                  Izbriši
                </button>
              )
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="h-12 flex-1 rounded-full border border-line px-4 text-sm font-medium text-ink sm:flex-none"
              >
                Prekliči
              </button>
              <button
                type="submit"
                className="h-12 flex-1 rounded-full bg-ribbon px-5 text-sm font-medium text-foam sm:flex-none"
              >
                Shrani
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium uppercase tracking-widest text-muted">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
